"/Applications/MATLAB_R2021a.app/toolbox/shared/coder/ninja/maci64/ninja" -t compdb cc cxx cudac > compile_commands.json
"/Applications/MATLAB_R2021a.app/toolbox/shared/coder/ninja/maci64/ninja" -v "$@"
