//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// _coder_abeles_loop_new_info.h
//
// Code generation for function 'abeles_loop_new'
//

#ifndef _CODER_ABELES_LOOP_NEW_INFO_H
#define _CODER_ABELES_LOOP_NEW_INFO_H

// Include files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
// End of code generation (_coder_abeles_loop_new_info.h)
