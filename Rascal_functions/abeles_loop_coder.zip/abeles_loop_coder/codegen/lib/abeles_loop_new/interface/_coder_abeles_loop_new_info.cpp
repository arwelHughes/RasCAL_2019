//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// _coder_abeles_loop_new_info.cpp
//
// Code generation for function 'abeles_loop_new'
//

// Include files
#include "_coder_abeles_loop_new_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

// Function Declarations
static const mxArray *emlrtMexFcnResolvedFunctionsInfo();

// Function Definitions
static const mxArray *emlrtMexFcnResolvedFunctionsInfo()
{
  const mxArray *nameCaptureInfo;
  const char_T *data[5]{
      "789ced95cb4ec24014860783c68517566e7c023756bca02c0511884008e0c218534b7b80"
      "ea5c6a2f020f605cfa4a2e7d0517ee7c05f7524a814e9c408296689c"
      "cde9e93f33dfb934a728922f4610426bc85bb915cfae0efcd8c02ea0e0e2f508b72f12dc"
      "8e16513470ced79f065665d4868eed395421303ca931a25385dab5ae",
      "01c8048be17bd0fa4a43c750d30954c79d92eb91d33169e8b892fb9c6e817a5b7508325b"
      "d628423cee0cebf122c8373a653d14413d629c7e99b992ce2d302d49"
      "31db80a513a63a04a86d492ad374da942a8a953e2ec8bb3bf1a4fbac2a586e3854b57546"
      "7b67ea80c192316386dcdb0f66e00d85f636e1f23266cc8bef239f97",
      "af0fe2b07a296018e35fcfc85f12f23d45634edd05fabce71979b29017d47fa88f5efd7a"
      "5d9c54bff529f3e1ed68ff72dfb60edffb88b078c5b78ffd3079fe9a"
      "17af23b86fdaef7143c08b717ab1488f9472462bc70b55d24cd7f217cd9b547614477902"
      "67521c48e08775ffff7cfe3a2f511d639cedff501d374ad9601877e7",
      "359f67ed635dc80beadfdd47be7e7e23c39a2b0f9b1d254cde63e2752b4c9ebffefa9cb6"
      "4b249938cbc6ef72ad8ab197326a903c68667eff9cfe042b64f27d",
      ""};
  nameCaptureInfo = nullptr;
  emlrtNameCaptureMxArrayR2016a(&data[0], 3168U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties()
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6]{
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  const char_T *propFieldName[5]{"Version", "ResolvedFunctions", "EntryPoints",
                                 "CoverageInfo", "IsPolymorphic"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 7);
  emlrtSetField(xEntryPoints, 0, (const char_T *)"Name",
                emlrtMxCreateString((const char_T *)"abeles_loop_new"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfInputs",
                emlrtMxCreateDoubleScalar(7.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, (const char_T *)"FullPath",
      emlrtMxCreateString(
          (const char_T
               *)"/Users/arwel/Documents/coding/RasCAL_2019/Rascal_functions/"
                 "abeles_loop_coder/abeles_loop_new.m"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"TimeStamp",
                emlrtMxCreateDoubleScalar(738471.39126157411));
  xResult =
      emlrtCreateStructMatrix(1, 1, 5, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, (const char_T *)"Version",
                emlrtMxCreateString((const char_T *)"9.10.0.1602886 (R2021a)"));
  emlrtSetField(xResult, 0, (const char_T *)"ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, (const char_T *)"EntryPoints", xEntryPoints);
  return xResult;
}

// End of code generation (_coder_abeles_loop_new_info.cpp)
