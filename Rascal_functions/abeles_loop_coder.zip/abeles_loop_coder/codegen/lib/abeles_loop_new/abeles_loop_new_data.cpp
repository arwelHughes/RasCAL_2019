//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_loop_new_data.cpp
//
// Code generation for function 'abeles_loop_new_data'
//

// Include files
#include "abeles_loop_new_data.h"

// End of code generation (abeles_loop_new_data.cpp)
