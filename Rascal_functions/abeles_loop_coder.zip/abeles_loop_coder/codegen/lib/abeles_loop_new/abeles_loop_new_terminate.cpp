//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_loop_new_terminate.cpp
//
// Code generation for function 'abeles_loop_new_terminate'
//

// Include files
#include "abeles_loop_new_terminate.h"

// Function Definitions
void abeles_loop_new_terminate()
{
  // (no terminate code required)
}

// End of code generation (abeles_loop_new_terminate.cpp)
