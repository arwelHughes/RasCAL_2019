//
// Non-Degree Granting Education License -- for use at non-degree
// granting, nonprofit, educational organizations only. Not for
// government, commercial, or other organizational use.
//
// abeles_loop_new_initialize.h
//
// Code generation for function 'abeles_loop_new_initialize'
//

#ifndef ABELES_LOOP_NEW_INITIALIZE_H
#define ABELES_LOOP_NEW_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void abeles_loop_new_initialize();

#endif
// End of code generation (abeles_loop_new_initialize.h)
