%% Build the mex file for the current platform
% Then generate clean source code

% Build the mex
abeles_loop_new_compile_script;

% Make clean source code
abeles_loop_new_codeOnly_compile_script;
