/*
 * Non-Degree Granting Education License -- for use at non-degree
 * granting, nonprofit, educational organizations only. Not for
 * government, commercial, or other organizational use.
 *
 * callParatt_data.c
 *
 * Code generation for function 'callParatt_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "callParatt.h"
#include "callParatt_data.h"

/* Variable Definitions */
omp_nest_lock_t emlrtNestLockGlobal;

/* End of code generation (callParatt_data.c) */
